# Cloud Technologies
#Облачные технологии и услуги#

Участники группы: Хисаметдинова Динара (https://gitlab.com/khdinova), Филиппов Артём (https://gitlab.com/ssuperartem), Беломытцев Андрей, Фадеев Дмитрий (https://gitlab.com/Ayfilor)

Аналитическая лабораторная по облакам: [Лаб_1](https://gitlab.com/meow9012838/cloud-technologies/-/blob/main/README.md?ref_type=heads)
